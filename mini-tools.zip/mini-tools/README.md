http://bbs.wuyou.net/forum.php?mod=viewthread&tid=273214

本帖最后由 qh6420933 于 2015-7-31 11:48 编辑


有时候用MaxDos服务端不太好用，更新个tftpd32版，引导文件用的grub，引导文件的配置menu.lst，IMG用的还是MaxDOS9.3版
使用前请配置好tftpd的dhcp服务，tftp服务默认即可，引导文件填写grub.0，启动脚本是照别人的改的

下载地址：
http://pan.baidu.com/s/1dDwGRID 密码: 23hp

注意：多块硬盘，不建议使用启动脚本操作！如需操作，请谨慎操作！！~

----------------------------------------------以下是MaxDOS服务端版，启动脚本暂未更新------------------------------------------------
老7.1版 带不起来新机器
自己用PXELINUX.0 做了个MaxDos 9.3 pex 网刻版
下载地址：
http://pan.baidu.com/s/1gdzPkDP

1、保留原MaxDOS 7.1 PXE版。 
2、MAXDOS.IMG为最新MAXDOS 9.3版，网启方式使用PXELINUX.0 PXE引导。
        使用方法：
        1）网络设置里启动文件选择 PXELINUX.0
        2）网络设置里引导文件选择 MAXDOS.IMG
3、当MAXDOS更新时，可直接替换MAXDOS.IMG为最新版IMG文件，编辑PXELINUX.CFG下的DEFAULT(用记事本编辑)文件中CHS参数为新

版MAXDOS.IMG的CHS参数即可。

更新20121217
1、添加DHCP手动网刻，提供解决MaxDOS不能DHCP分配IP的地址功能的替补方案。
2、手动配置DHCP server，IP起始地址、IP地址池大小、启动文件名（PXE文件，MaxDOS9.3PXE为PXELINUX.0）、默认路由（网关）、子掩码。
3、手动批处理，镜像保存路径为MAXDOS下Ghobak目录。
        1）全盘：disk目录为全盘镜像目录，保存文件名为Disk.gho
        2）C盘：Partition目录为C盘镜像目录，        保存文件名为Cpan.gho
        注：恢复镜像名同制作镜像路径、文件名一样。
4、如需要手动备份、恢复其他分区或选择、存储非默认目录的gho文件，可先手动停止GhostSrv，修改参数后再启动。
5、添加IMG的CHS参数查看工具GDPARAM，方便更新MaxDOS.IMG文件。


已更新 20140929
[ 本帖最后由 qh6420933 于 2012-12-17 18:19 编辑 ]