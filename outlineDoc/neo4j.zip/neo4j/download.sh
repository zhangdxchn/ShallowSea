#!/bin/sh


#wget -m -c -np -k -E -p https://www.elastic.co/guide/en/elasticsearch/reference/7.0/index.html
#wget -m -c -np -k -E -p https://www.elastic.co/guide/en/elasticsearch/client/java-api/7.1/index.html

#wget -m -c -np -k -E -p https://m.runoob.com/mongodb/
#wget -m -c -np -k -E -p https://docs.mongodb.com/manual/
#wget -m -c -np -k -E -p https://docs.oracle.com/javase/tutorial/

#nohup wget -m -c -np -k -E -p https://ci.apache.org/projects/flink/flink-docs-release-1.8/ > flink.log 2>&1 & 

#wget -m -c -np -k -E -p https://developers.google.cn/machine-learning/crash-course/

#nohup wget -m -c -np -k -E -p https://neo4j.com/docs/ > neo4j1.log 2>&1 &
nohup wget  -m -c -np -H -D www.w3cschool.cn,7n.w3cschool.cn,7nsts.w3cschool.cn -k -E -p https://www.w3cschool.cn/neo4j/ > neo4j2.log  2>&1 &
#nohup wget -m -c -np -k -E -p https://hbase.apache.org/book.html > hbase.log 2>&1 &

#nohup wget -m -c -np -k -E -p https://vuex.vuejs.org/zh/guide/ > vuex.log 2>&1 &
#wget -m -x -c -np -k -p https://element.eleme.io/
#wget -m -x -c -np -k -p https://shadow.elementcdn.com/

#wget -m -c -np -k -E -p https://lodash.com/
